def lambda_handler(event, context):
    print("funcionou!")

    return {
        'statusCode': 200,
    }
